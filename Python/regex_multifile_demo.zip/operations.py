import re #regex!
from pathlib import Path
import os

def open_file_read_text(path: Path) -> list[str]:
    
    if not os.path.isfile(path):
        raise FileNotFoundError("Given location is incorrect!")
    
    with open(path) as f:
        return f.readlines()
    
def extract_data() -> dict[int, dict]:
    seat_pattern = r"(?<=Seats=)\d"
    make_pattern = r"(?<=Make=)\S+"
    id_pattern=r"(?<=ID[=|:])\S+"
    type_pattern=r"(?<=Type=)\S+"
    

    #ask python to open files and extract data in a "collection of lines"
    data = open_file_read_text("data.txt")
    
    answer = {}
    #now use re module to apply pattern on "collection of lines" [one str at a time]
    for idx, line in enumerate(data):
        seat_result = re.findall(seat_pattern,  line)[0]
        make_result = re.findall(make_pattern,  line)[0]
        id_result = re.findall(id_pattern,  line)[0]
        type_result = re.findall(type_pattern,  line)[0]

        line_result = {  "ID" : id_result, "Make" : make_result, "Seat_Count" : seat_result, "Type" : type_result  }
        answer.update({ idx : line_result})

    return answer