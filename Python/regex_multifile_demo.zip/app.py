

from pprint import pprint
from operations import extract_data

def main() -> None:
    answer = extract_data()
    pprint(answer)

if __name__ == "__main__":
    main()